package com.example.manytoonedemouni.service;

import com.example.manytoonedemouni.domain.Category;

public interface CategoryService {

	public Category save(Category category);
}
