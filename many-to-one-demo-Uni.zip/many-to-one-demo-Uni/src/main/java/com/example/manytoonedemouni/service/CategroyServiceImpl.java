package com.example.manytoonedemouni.service;

import org.springframework.stereotype.Service;

import com.example.manytoonedemouni.domain.Category;
import com.example.manytoonedemouni.repository.CategoryRepository;

@Service
public class CategroyServiceImpl implements CategoryService{
	
	private final CategoryRepository categoryRepository;
	
	

	public CategroyServiceImpl(CategoryRepository categoryRepository) {
		super();
		this.categoryRepository = categoryRepository;
	}



	@Override
	public Category save(Category category) {
		
		return null;
	}

}
