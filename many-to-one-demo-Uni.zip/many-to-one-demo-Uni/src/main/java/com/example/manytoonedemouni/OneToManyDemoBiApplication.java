package com.example.manytoonedemouni;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.manytoonedemouni.service.IDatabase;

@SpringBootApplication
public class OneToManyDemoBiApplication {
	
	private final IDatabase iDatabase;
		

	public OneToManyDemoBiApplication(IDatabase iDatabase) {
		super();
		this.iDatabase = iDatabase;
	}

	public static void main(String[] args) {
		SpringApplication.run(OneToManyDemoBiApplication.class, args);
	}
	
	@Bean
	public CommandLineRunner runner() {
		return a->{
			iDatabase.createDatabase();
		};
	}

}
