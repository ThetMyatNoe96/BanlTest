package com.example.manytoonedemouni.service;

public interface IDatabase {

	void createDatabase();
}
