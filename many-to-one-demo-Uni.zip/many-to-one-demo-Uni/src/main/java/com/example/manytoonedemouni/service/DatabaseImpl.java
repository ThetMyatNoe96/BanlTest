package com.example.manytoonedemouni.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.manytoonedemouni.domain.Category;
import com.example.manytoonedemouni.domain.Products;
import com.example.manytoonedemouni.repository.CategoryRepository;
import com.example.manytoonedemouni.repository.ProductRepository;

@Service
public class DatabaseImpl implements IDatabase{
	
	private final CategoryRepository categoryRepository;
	private final ProductRepository productRepository;
	
	

	public DatabaseImpl(CategoryRepository categoryRepository, ProductRepository productRepository) {  // This is constructor injection
		super();
		this.categoryRepository = categoryRepository;
		this.productRepository = productRepository;
	}

	@Override
	@Transactional
	public void createDatabase() {
		
		Category c1=new Category();
		c1.setName("Fruits");
		
		Category c2=new Category();
		c2.setName("Meats");
		
		Products p1=new Products("Apple",20,1000);
		Products p2=new Products("Orange",20,500);
		Products p3=new Products("Chicken",20,10000);
		Products p4=new Products("Fish",20,5000);
		
		p1.setCategory(c1);
		p2.setCategory(c1);

		p3.setCategory(c2);
		p4.setCategory(c2);
	
		categoryRepository.save(c1);
		categoryRepository.save(c2);
		
		productRepository.save(p1);
		productRepository.save(p2);
		productRepository.save(p3);
		productRepository.save(p4);
		
		
		
		
	}

}
