package com.example.onetomanydemobi.service;

import com.example.onetomanydemobi.domain.Category;

public interface CategoryService {

	public Category save(Category category);
}
