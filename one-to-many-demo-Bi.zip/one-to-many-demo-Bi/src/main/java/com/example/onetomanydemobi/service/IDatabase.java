package com.example.onetomanydemobi.service;

public interface IDatabase {

	void createDatabase();
}
