package com.example.onetomanydemobi.service;

import org.springframework.stereotype.Service;

import com.example.onetomanydemobi.domain.Category;
import com.example.onetomanydemobi.repository.CategoryRepository;

@Service
public class CategroyServiceImpl implements CategoryService{
	
	private final CategoryRepository categoryRepository;
	
	

	public CategroyServiceImpl(CategoryRepository categoryRepository) {
		super();
		this.categoryRepository = categoryRepository;
	}



	@Override
	public Category save(Category category) {
		
		return null;
	}

}
