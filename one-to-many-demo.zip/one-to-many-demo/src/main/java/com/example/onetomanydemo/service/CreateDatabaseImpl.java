package com.example.onetomanydemo.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.onetomanydemo.domain.Category;
import com.example.onetomanydemo.domain.Products;
import com.example.onetomanydemo.repository.CategoryRepository;
import com.example.onetomanydemo.repository.ProductRepository;

@Service
public class CreateDatabaseImpl implements ICreateDatabase {

	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private CategoryRepository categoryRepository;


	@Transactional
	@Override
	public void CreateDatabase() {
		
		Category c1=new Category("Meat");
		Category c2=new Category ("Fruits");
		
		Products p1=new Products ("Chicken", 20,10000);
		Products p2=new Products("Fish",20,5000);
		Products p3=new Products("Apple",10,500);
		Products p4=new Products("Orange",10,800);
		
		c1.getProduct().add(p1);
		c1.getProduct().add(p2);
		
		c2.getProduct().add(p3);
		c2.getProduct().add(p4);
		
		categoryRepository.save(c1);
		categoryRepository.save(c2);
		
	}

}
