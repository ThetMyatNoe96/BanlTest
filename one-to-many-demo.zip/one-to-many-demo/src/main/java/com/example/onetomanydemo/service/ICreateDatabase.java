package com.example.onetomanydemo.service;


public interface ICreateDatabase {
	
	void CreateDatabase();

}
