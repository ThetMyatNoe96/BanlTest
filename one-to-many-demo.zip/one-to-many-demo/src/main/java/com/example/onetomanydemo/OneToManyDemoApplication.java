package com.example.onetomanydemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.onetomanydemo.service.ICreateDatabase;

@SpringBootApplication
public class OneToManyDemoApplication {
	
	@Autowired
	private ICreateDatabase iCreateDatabase;

	public static void main(String[] args) {
		SpringApplication.run(OneToManyDemoApplication.class, args);
	}

	@Bean
	public CommandLineRunner runner() {
		return a->{
			
			iCreateDatabase.CreateDatabase();
		};
	}
}
