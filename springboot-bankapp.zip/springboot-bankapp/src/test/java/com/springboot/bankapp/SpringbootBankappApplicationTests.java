package com.springboot.bankapp;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.springboot.bankapp.model.User;
import com.springboot.bankapp.repository.UserRepository;
import com.springboot.bankapp.service.UserService;

@SpringBootTest
class SpringbootBankappApplicationTests {

	@Autowired
	private UserService userService;
	
	@MockBean
	@Autowired
	private UserRepository userRepository;

	@Test
	public void getAllUserstest() {
		when(userRepository.findAll()).thenReturn(Stream.of(new User(1,"Singapore, Boonlay","thetmyatnoe@gmail.com","Thet","Myat Noe","22211","ilovespring","111111"), new User(2,"Singapore, Boonlay","noe@gmail.com","Nanon","Kanawat","222222","ilovespring","222222")).collect(Collectors.toList()));
		assertEquals(2, userService.getAllUser().size());
		
	}
}
