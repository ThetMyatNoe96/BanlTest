package com.springboot.bankapp.UserTest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.Extensions;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.springboot.bankapp.dto.UserAccountDto;
import com.springboot.bankapp.dto.UserDto;
import com.springboot.bankapp.exception.UserAccountNotFoundException;
import com.springboot.bankapp.model.User;
import com.springboot.bankapp.repository.UserRepository;
import com.springboot.bankapp.service.UserService;


@SpringBootTest

class UserServiceTest {
	
	@Autowired
	private UserService userService;
	
	@MockBean
	@Autowired
	private UserRepository userRepository;
	
	

	@Test
	public void getAllUsersTest() {
		when(userRepository.findAll()).thenReturn(Stream.of(new User(1,"Singapore, Boonlay","thetmyatnoe@gmail.com","Thet","Myat Noe","22211","ilovespring","111111"), new User(2,"Singapore, Boonlay","noe@gmail.com","Nanon","Kanawat","222222","ilovespring","222222")).collect(Collectors.toList()));
		assertEquals(2, userService.getAllUser().size());
		
	}
		
	@Test
	public void getUserByIdTest() {
		long userId=1L;
		User user =new User(userId,"Thet","Myat Noe","thetmyatnoe@gmail.com","ilovespring","22211","Singapore, Boonlay","111111");	
		doReturn(Optional.of(user)).when(userRepository).findById(userId);
		User mockuser=userService.getUserById(userId);
		
		assertEquals("thetmyatnoe@gmail.com", mockuser.getEmail());
		
		
	}
	
	@Test
	public void saveUserTest() {
		
		long accountId=2;		
		User user =new User(3,"Singpore , Lavender","shwe@gmail.com","Shwe","Shwe","333333","ilovespring","123456");
		UserAccountDto userdto=new UserAccountDto(3,"Shwe","Shwe","shwe@gmail.com",accountId,"362000","Shwe Shwe",BigDecimal.ZERO,"333333","123456");
		
		when(userRepository.save(user)).thenReturn(user);
		UserAccountDto userdto2=new UserAccountDto();
	}
}
