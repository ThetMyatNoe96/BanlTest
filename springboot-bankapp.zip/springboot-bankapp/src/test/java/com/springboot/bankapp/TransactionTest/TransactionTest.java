package com.springboot.bankapp.TransactionTest;


import org.junit.jupiter.api.Test;

import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.springboot.bankapp.repository.TransactionRepository;

import com.springboot.bankapp.service.TransactionService;


@SpringBootTest
class TransactionTest {

	@Autowired
	private TransactionService transService;
	
	@MockBean
	@Autowired
	private TransactionRepository transRepository;
	
	
	@Test
	public void changeAccountBalanceByIdTest() {
		long accId=2;
		double newBalance=1000;
		transService.changeAccountBalanceById(newBalance, accId);
		Mockito.verify(transRepository,Mockito.timeout(1)).changeAccountBalanceById(newBalance, accId);
	
		
	}
	

}
