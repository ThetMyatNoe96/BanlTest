package com.springboot.bankapp.service.Impl;


import org.springframework.stereotype.Service;

import com.springboot.bankapp.model.Beneficiary;
import com.springboot.bankapp.repository.BeneficiaryRepository;
import com.springboot.bankapp.service.BeneficiaryService;

@Service
public class BeneficiaryServiceImpl implements BeneficiaryService {

	private BeneficiaryRepository beneRepository;
	
	public BeneficiaryServiceImpl(BeneficiaryRepository beneRepository) {
		super();
		this.beneRepository = beneRepository;
	}

	@Override
	public Beneficiary saveBeneficiary(Beneficiary beneficiary) {
		
		return beneRepository.save(beneficiary);
	}

	@Override
	public Beneficiary getBenefiByAccNum(String accNumber) {
				
			return beneRepository.getBenefiByAccNum(accNumber);
					
	}
		
	

}
