package com.springboot.bankapp.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.bankapp.dto.DepositWithdrawDto;
import com.springboot.bankapp.dto.TransactionDto;
import com.springboot.bankapp.dto.TransactionHistoryDto;
import com.springboot.bankapp.dto.TransferDto;
import com.springboot.bankapp.exception.CommonTransactionalException;

import com.springboot.bankapp.model.Transaction;
import com.springboot.bankapp.service.BeneficiaryService;
import com.springboot.bankapp.service.TransactionService;

@RestController
@RequestMapping("/transaction")
public class TransactionController {
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private TransactionService transService;
	
	@Autowired
	private BeneficiaryService benefiService;
	

	@GetMapping("/getExistingBal/{id}")
	public double getExistingBal(@PathVariable("id") long accountId){		
		
		return transService.getExistingBalance(accountId);
		
	}
	
	@PostMapping("/deposit")
	public ResponseEntity<Double> deposite( @RequestBody DepositWithdrawDto depositWidthdrawDto) 
	{
		String depositAmount= depositWidthdrawDto.getAmount();
		String accountId=depositWidthdrawDto.getAccountId();
		
		if(depositAmount.isEmpty() || accountId.isEmpty()){
			
			 throw new CommonTransactionalException("Deposit Amount or Account Depositing to Cannot Be Empty!");
		}
		double depositAmountValue = Double.parseDouble(depositAmount);
		
		if (depositAmountValue == 0) {
			throw new CommonTransactionalException("Deposit Amount Cannot Be of 0 (Zero) Value !");
		}
		long account_Id=Long.parseLong(accountId);
		double currentBalance=transService.getExistingBalance(account_Id);	
		double newBalance=currentBalance + depositAmountValue;
		transService.changeAccountBalanceById(newBalance, account_Id);
		

		return new ResponseEntity<Double>(newBalance,HttpStatus.OK);
		
	}
	
	@PostMapping("/withdraw")
	public ResponseEntity<Double> withdraw (@RequestBody DepositWithdrawDto depositWidthdrawDto){
		
		String withdrawalAmount= depositWidthdrawDto.getAmount();
		String accountId=depositWidthdrawDto.getAccountId();
		
		 if(withdrawalAmount.isEmpty() || accountId.isEmpty()){
			 
			 throw new CommonTransactionalException("Withdrawal Amount and Account Withdrawing From Cannot be Empty");
		 }
		
		double withdrawal_Amount = Double.parseDouble(withdrawalAmount);
		long account_Id=Long.parseLong(accountId);
		double currentBalance=transService.getExistingBalance(account_Id);	
		
		if (currentBalance < withdrawal_Amount) {
			 throw new CommonTransactionalException("You Have insufficient Funds to perform this Withdrawal!");
		}
		
		double newBalance=currentBalance - withdrawal_Amount;
		transService.changeAccountBalanceById(newBalance, account_Id);
		
		return new ResponseEntity<Double>(newBalance,HttpStatus.OK);
	}
	
	
	@PostMapping("/transfer")
	public ResponseEntity<TransactionHistoryDto> transfer(@RequestBody TransferDto transferDto)
	
	{
		String transfer_fromId=transferDto.getTransferFromId();
		String transfer_FromName=transferDto.getTransferFromName();
		String transfer_toId=transferDto.getTransferToId();
		String transfer_amount=transferDto.getTransferAmount();
		
		 if(transfer_fromId.isEmpty() || transfer_FromName.isEmpty() || transfer_amount.isEmpty()){
			 
			 throw new CommonTransactionalException("The account transferring from and to along with the amount cannot be empty!");
             
		 }
		 
		if (benefiService.getBenefiByAccNum(transfer_toId) == null) {
			
			throw new CommonTransactionalException("The account that you want to transfer haven't registered yet !");
			
		}
			
		long transferFromId=Long.parseLong(transfer_fromId);
		LocalDateTime currentDateTime = LocalDateTime.now();
		double transferAmount = Double.parseDouble(transfer_amount);
		
		double currentBalance=transService.getExistingBalance(transferFromId);
		
		if (transferAmount==0) {
			throw new CommonTransactionalException("Cannot Transfer an amount of 0 (Zero) value, please enter a value greater than 0 (Zero)");
		}
		
		if (currentBalance < transferAmount) {
			 throw new CommonTransactionalException("You Have insufficient Funds to perform this Transfer!");
		}	
		
		
		double newBalance=currentBalance - transferAmount;
		transService.changeAccountBalanceById(newBalance, transferFromId);
		
		Transaction tran=new Transaction();
		tran.setTransferFrom(transferFromId);
		tran.setAccountName(transfer_FromName);		
		tran.setTransactionType("Online Transfer");
		tran.setTransferTo(transfer_toId);
		tran.setAmount(transferAmount);
		tran.setStatus("Processing");
		tran.setCreated_at(currentDateTime);
		
		Transaction trans=transService.saveTransaction(tran);
		TransactionHistoryDto transResponse=modelMapper.map(trans,TransactionHistoryDto.class);
		transResponse.setRemianingBalance(newBalance);
		transResponse.setStatus("success");
		
		return new ResponseEntity<TransactionHistoryDto>(transResponse,HttpStatus.OK);
	
		
	}
	
	@GetMapping
	public List<TransactionDto> getAllTransaction(){
				
		return transService.getTransaction();		
	}
	
	@GetMapping("/getTransByDate")
	public List<TransactionDto> getTransactionByDate( @RequestParam("date_from") String date_from,
			  								@RequestParam("date_to") String date_to)		
		
	{
		
		date_from=date_from+" 00:00:00";
		date_to=date_to+" 00:00:00";
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"); 
		LocalDateTime dateFrom = LocalDateTime.parse(date_from, formatter);
		LocalDateTime dateTo = LocalDateTime.parse(date_to, formatter);

		
		return transService.getTransactionByDate(dateFrom, dateTo);
		
	}
	
}
