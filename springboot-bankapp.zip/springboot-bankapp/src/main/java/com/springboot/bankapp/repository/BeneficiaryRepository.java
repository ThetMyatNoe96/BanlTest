package com.springboot.bankapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.springboot.bankapp.model.Beneficiary;

public interface BeneficiaryRepository extends JpaRepository<Beneficiary, Long>{

	 @Query (value = "SELECT * FROM beneficiary WHERE account_number= :accNumber", nativeQuery = true)
	    Beneficiary getBenefiByAccNum(String accNumber);
	    

}
