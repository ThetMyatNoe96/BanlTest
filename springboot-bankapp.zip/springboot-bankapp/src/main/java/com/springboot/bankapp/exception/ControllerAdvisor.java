package com.springboot.bankapp.exception;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class ControllerAdvisor extends ResponseEntityExceptionHandler {

	@ExceptionHandler(UserAccountNotFoundException.class)
	public ResponseEntity<Object>  handleException(UserAccountNotFoundException exc)
	{
		
		List<String> details=new ArrayList<String>();
		details.add(exc.getLocalizedMessage());
		ErrorResponse error=new ErrorResponse("Record Not Found",details);
				
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
		
	}
	
	@ExceptionHandler(CommonTransactionalException.class)
	public ResponseEntity<Object>  handleException(CommonTransactionalException exc)
	{
		
		List<String> details=new ArrayList<String>();
		details.add(exc.getLocalizedMessage());
		ErrorResponse error=new ErrorResponse("Error processing Request",details);
				
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
		
	}
	@ExceptionHandler(DBException.class)
	public ResponseEntity<Object>  handleException(DBException exc)
	{
		
		List<String> details=new ArrayList<String>();
		details.add(exc.getLocalizedMessage());
		ErrorResponse error=new ErrorResponse("SQL Exception",details);
				
		return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
		
	}
	
	/*
	 * 
	 * @ExceptionHandler({Exception.class})
	  protected ResponseEntity<Object> handleAll(Exception ex,WebRequest request){
		
	    List<String> details = new ArrayList<>();
	    details.add(ex.getLocalizedMessage());
	    ErrorResponse error = new ErrorResponse("Error Processing Request", details);
	    
	    return new ResponseEntity<Object>(error, HttpStatus.BAD_REQUEST);
	        
	    
	  }		
	

	
	 */
	
	
	
	@Override
	  protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
		
	    List<String> details = new ArrayList<>();
	    for(ObjectError error : ex.getBindingResult().getAllErrors()) {
	      details.add(error.getDefaultMessage());
	    }
	    ErrorResponse error = new ErrorResponse("Validation Failed", details);
	    
	    return new ResponseEntity<Object>(error, HttpStatus.BAD_REQUEST);
	  }
	
}
