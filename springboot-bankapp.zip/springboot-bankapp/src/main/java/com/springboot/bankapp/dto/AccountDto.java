package com.springboot.bankapp.dto;

import java.math.BigDecimal;


import lombok.Data;

@Data
public class AccountDto {

	private long accountId;
	private UserDto user;	
	private String accountNumber;
	private String accountHolderName;
	private BigDecimal balance;
}
