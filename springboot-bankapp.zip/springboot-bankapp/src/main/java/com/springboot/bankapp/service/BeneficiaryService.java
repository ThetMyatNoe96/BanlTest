package com.springboot.bankapp.service;

import com.springboot.bankapp.model.Beneficiary;

public interface BeneficiaryService {

	Beneficiary saveBeneficiary(Beneficiary beneficiary);
	
	Beneficiary getBenefiByAccNum(String accNumber);
	
}
