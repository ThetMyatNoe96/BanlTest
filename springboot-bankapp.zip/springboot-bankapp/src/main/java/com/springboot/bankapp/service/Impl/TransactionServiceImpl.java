package com.springboot.bankapp.service.Impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.bankapp.dto.TransactionDto;
import com.springboot.bankapp.model.Transaction;
import com.springboot.bankapp.repository.TransactionRepository;
import com.springboot.bankapp.service.TransactionService;

@Service
public class TransactionServiceImpl implements TransactionService{
	
	private TransactionRepository transRepository;
	
	@Autowired
	private ModelMapper modelMapper;
	
	public TransactionServiceImpl(TransactionRepository transRepository) {
		super();
		this.transRepository = transRepository;
	}

	@Override
	public double getExistingBalance(long account_id) {
		
		double existingBalance=transRepository.getExistingBalance(account_id);
		return existingBalance;
	}

	@Override
	public void changeAccountBalanceById(double new_balance, long account_id) {
		transRepository.changeAccountBalanceById(new_balance, account_id);
		
	}

	@Override
	public Transaction saveTransaction(Transaction trans) {
		return transRepository.save(trans);
	}

	@Override
	public List<TransactionDto> getTransaction() {
		
		return transRepository.getTransaction().stream().map(this::convertEntityToDto).collect(Collectors.toList());
	}

	@Override
	public List<TransactionDto> getTransactionByDate(LocalDateTime from_date, LocalDateTime to_date) {
		
		return transRepository.getTransactionByDate(from_date, to_date).stream().map(this::convertEntityToDto).collect(Collectors.toList());
	}

	
	  private TransactionDto convertEntityToDto(Transaction trans){
	        modelMapper.getConfiguration()
	                .setMatchingStrategy(MatchingStrategies.LOOSE);
	        TransactionDto transDto = new TransactionDto();
	        transDto = modelMapper.map(trans, TransactionDto.class);
	        return transDto ;
	    }
}
