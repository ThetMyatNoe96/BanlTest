package com.springboot.bankapp.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data

@NoArgsConstructor
public class UserAccountDto {

	private long userId;
	private String firstName;
	private String lastName;
	private String email;
	private long accountId;
	private String accountNumber;
	private String accountHolderName;
	private BigDecimal balance;
	private String passport;
	private String phone;
	
	
	public UserAccountDto(long userId, String firstName, String lastName, String email, long accountId,
			String accountNumber, String accountHolderName, BigDecimal balance, String passport, String phone) {
		super();
		this.userId = userId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.accountId = accountId;
		this.accountNumber = accountNumber;
		this.accountHolderName = accountHolderName;
		this.balance = balance;
		this.passport = passport;
		this.phone = phone;
	}



	

}

