package com.springboot.bankapp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long userId;
	

	@NotEmpty(message = "The First name field cannot be empty")
	@Size(min=2,message="The First name field must greater that 3 characters")
	@Column(name="first_name",nullable = false)
	private String firstName;
	

	@NotEmpty(message = "The Last name field cannot be empty")
	@Size(min=2,message="The Last name field must greater that 3 characters")
	@Column(name="last_name")
	private String lastName;
	
	@Email
	@NotEmpty (message = "The Email field cannot be empty")
	@Pattern(regexp = "([a-zA-Z0-9]+(?:[._+-][a-zA-Z0-9]+)*)@([a-zA-Z0-9]+(?:[.-][a-zA-Z0-9]+)*[.][a-zA-Z]{2,})", message = "Please Enter a Valid Email")
	@Column(unique=true)
	private String email;
	
	
	@NotEmpty (message = "The Password field cannot be empty")
	private String password;
	
	@NotEmpty
	@NotNull (message = "The Passport field cannot be empty")
	@Column(unique=true)
	private String passport;
	
	@NotEmpty
	@NotNull (message = "The Address field cannot be empty")
	private String address;
	
	@NotNull
	//@Digits(fraction = 0, integer = 10)
	@Pattern(regexp = "([0-9]+)", message = "Please Enter a Valid Email")
	@Column(unique=true)
	private String phone;
	
}
