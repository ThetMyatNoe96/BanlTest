package com.springboot.bankapp.model;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
public class Beneficiary {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long beneficiaryId;	
	
	@NotNull(message = "The Related AccountId can't be empty")
	private long relatedAccountId;
	
	@NotEmpty (message = "The AccountHolder Name can't be empty")
	@Column(unique=true)
	private String accountHolderName;
	
	@NotEmpty (message = "The Account Number can't be empty")
	@Column(unique=true)
	private String accountNumber;
	
	@NotEmpty (message = "The BackUnique Code can't be empty")
	private String bankUniqueCode;
	
	
	
}
