package com.springboot.bankapp.dto;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class TransactionHistoryDto {

	private long transaction_id;
	private long transferFrom;
    private String accountName;
    private String transactionType;
    private String transferTo;
    private double amount;    
    private String status;   
    private LocalDateTime created_at;
    private double remianingBalance;
}
