package com.springboot.bankapp.service.Impl;

import org.springframework.stereotype.Service;


import com.springboot.bankapp.exception.UserAccountNotFoundException;
import com.springboot.bankapp.model.Account;
import com.springboot.bankapp.repository.AccountRepository;
import com.springboot.bankapp.service.AccountService;

@Service
public class AccountServiceImpl implements AccountService{
	
	private AccountRepository accountRepository;
	
	

	public AccountServiceImpl(AccountRepository accountRepository) {
		super();
		this.accountRepository = accountRepository;
	}




	@Override
	public Account saveAccount(Account account) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Account getAccountById(long id) {
		accountRepository.getById(id);
		

		return accountRepository.findById(id).orElseThrow(
				
				()-> new UserAccountNotFoundException("User_ID is not found "+ id));
		
			}
	

}
