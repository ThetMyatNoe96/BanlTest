package com.springboot.bankapp.model;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
public class Transaction {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private long transaction_id;
	
	@NotNull(message = "TransferFrom  field cannot be empty")
    private long transferFrom;
	
	@NotEmpty(message = "TransferFrom Account Name field cannot be empty")
    private String accountName;
    private String transactionType;
    
    @NotEmpty(message = "Transfer To field cannot be empty")
    private String transferTo;
    
    private double amount;    
    private String status;   
    private LocalDateTime created_at;
    
    


}
