package com.springboot.bankapp.exception;

public class CommonTransactionalException extends RuntimeException{

	public CommonTransactionalException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public CommonTransactionalException(String message) {
		super(message);
		
	}

	public CommonTransactionalException(Throwable cause) {
		super(cause);
		
	}

}
