package com.springboot.bankapp.service;

import java.time.LocalDateTime;
import java.util.List;

import com.springboot.bankapp.dto.TransactionDto;
import com.springboot.bankapp.model.Transaction;



public interface TransactionService {

	double getExistingBalance(long account_id);
	
	void changeAccountBalanceById (double new_balance,long account_id);
	
	Transaction saveTransaction(Transaction trans);
	
	 List<TransactionDto> getTransaction();
	 
	 List<TransactionDto> getTransactionByDate(LocalDateTime from_date,LocalDateTime to_date);
	
                       
	
	
}
