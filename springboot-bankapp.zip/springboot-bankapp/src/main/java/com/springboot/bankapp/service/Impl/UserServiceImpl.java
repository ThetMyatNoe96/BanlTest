package com.springboot.bankapp.service.Impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.springboot.bankapp.dto.UserAccountDto;

import com.springboot.bankapp.exception.DBException;
import com.springboot.bankapp.exception.UserAccountNotFoundException;
import com.springboot.bankapp.helper.ConvertEntityToDto;
import com.springboot.bankapp.helper.GenAccountNumber;
import com.springboot.bankapp.model.Account;
import com.springboot.bankapp.model.User;
import com.springboot.bankapp.repository.AccountRepository;
import com.springboot.bankapp.repository.UserRepository;
import com.springboot.bankapp.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	private UserRepository userRepository;
	
	private AccountRepository accountRepository;
	

	public UserServiceImpl(UserRepository userRepository, AccountRepository accountRepository) {
		super();
		this.userRepository = userRepository;
		this.accountRepository = accountRepository;
	}

	@Override
	@Transactional
	public UserAccountDto saveUser(User user) {
		
		try {
			
			User newUser= userRepository.save(user);
			
			Account newAccount=new Account();
			int setAccountNumber=GenAccountNumber.generateAccountNumber();
			String bankAccountNumber=Integer.toString(setAccountNumber);
			
			newAccount.setUser(newUser);
			newAccount.setAccountNumber(bankAccountNumber);
			newAccount.setAccountHolderName(user.getFirstName()+" "+user.getLastName());
			
			accountRepository.save(newAccount);
					
			
			return ConvertEntityToDto.convertDto(newUser,newAccount);
		}
		
		catch (Exception e) {
			throw new DBException("SQL Exception "+ e.getLocalizedMessage());
		}
	}

	@Override
	public List<User> getAllUser() {
		List<User> users=userRepository.findAll();
		System.out.println("Getting data from DB : "+ users);
		return users;
	}

	@Override
	public User getUserById(long id) {
		
		
	User user = userRepository.findById(id).orElseThrow(
			
			()-> new UserAccountNotFoundException("User_ID is ============================not found "+ id));
	
		System.out.println("Getting data from DB  getUserById: "+ user);
	
		return user;
		
	}

	@Override
	public User updateUser(User user, long id) {		
		
	
		User userinfo=userRepository.findById(id).orElseThrow(()-> new UserAccountNotFoundException("User_ID is not found "+ id));
		userinfo.setPhone(user.getPhone());
		userinfo.setAddress(user.getAddress());
		userinfo.setEmail(user.getEmail());
		userinfo.setFirstName(user.getFirstName());
		userinfo.setLastName(user.getLastName());
		userinfo.setPassport(user.getPassport());
		userinfo.setPassword(user.getPassword());
		userinfo.setUserId(user.getUserId());
		
		return userRepository.save(userinfo);
	}

}
