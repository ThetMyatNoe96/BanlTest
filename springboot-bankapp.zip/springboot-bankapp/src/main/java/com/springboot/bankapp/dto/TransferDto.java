package com.springboot.bankapp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TransferDto {

	private String transferFromId;
	private String transferFromName;
	private String transferToId;
	private String transferAmount;
	
}
