package com.springboot.bankapp.dto;

import lombok.Data;

@Data
public class BeneficiaryDto {
	
	private long beneficiaryId;		
	private long relatedAccountId;
	private String accountHolderName;
	private String accountNumber;
	private String bankUniqueCode;
	
}
