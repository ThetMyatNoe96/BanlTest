package com.springboot.bankapp.exception;

public class UserAccountNotFoundException extends RuntimeException{

	public UserAccountNotFoundException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public UserAccountNotFoundException(String message) {
		super(message);
		
	}

	public UserAccountNotFoundException(Throwable cause) {
		super(cause);
		
	}

}
