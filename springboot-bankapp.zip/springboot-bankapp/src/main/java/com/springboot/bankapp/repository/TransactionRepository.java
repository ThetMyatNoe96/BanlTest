package com.springboot.bankapp.repository;


import java.time.LocalDateTime;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.springboot.bankapp.model.Transaction;

public interface TransactionRepository extends JpaRepository<Transaction,Long>{

	@Query(value = "SELECT balance FROM account WHERE account_id = :account_id", nativeQuery = true)
    double getExistingBalance(@Param("account_id") long account_id);

    @Modifying
    @Query(value ="UPDATE account SET balance = :new_balance WHERE account_id = :account_id" , nativeQuery = true)
    @Transactional
    void changeAccountBalanceById(@Param("new_balance") double new_balance, @Param("account_id") long account_id);
    
  
    @Query (value = "SELECT * FROM transaction ORDER BY transaction_id DESC Limit 0,10", nativeQuery = true)
    List<Transaction> getTransaction();
    
    @Query(value = "SELECT * FROM transaction WHERE created_at >= :from_date AND created_at <= :to_date ", nativeQuery = true)
    List<Transaction> getTransactionByDate(@Param("from_date") LocalDateTime from_date, @Param("to_date") LocalDateTime to_date);
    
    
    
    
    
    
    
    
}
