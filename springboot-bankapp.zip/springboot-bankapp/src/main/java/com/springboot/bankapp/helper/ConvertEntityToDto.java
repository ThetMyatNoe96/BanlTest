package com.springboot.bankapp.helper;


import com.springboot.bankapp.dto.UserAccountDto;
import com.springboot.bankapp.model.Account;

import com.springboot.bankapp.model.User;


public class ConvertEntityToDto {

	
	public static UserAccountDto convertDto(User user,Account account) {
		
		UserAccountDto userAccountDto=new UserAccountDto();
		userAccountDto.setUserId(user.getUserId());
		userAccountDto.setFirstName(user.getFirstName());
		userAccountDto.setLastName(user.getLastName());
		userAccountDto.setEmail(user.getEmail());
		userAccountDto.setAccountId(account.getAccountId());
		userAccountDto.setAccountNumber(account.getAccountNumber());
		userAccountDto.setAccountHolderName(account.getAccountHolderName());
		userAccountDto.setBalance(account.getBalance());
		userAccountDto.setPassport(account.getUser().getPassport());
		userAccountDto.setPhone(account.getUser().getPhone());
		
		return userAccountDto;
	}

	
	
}

