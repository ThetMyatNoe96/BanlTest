package com.springboot.bankapp.service;

import java.util.List;

import com.springboot.bankapp.dto.UserAccountDto;

import com.springboot.bankapp.model.User;


public interface UserService {

	UserAccountDto saveUser(User user);
		
	List<User> getAllUser();
	
	User getUserById(long id);
	
	User updateUser(User user, long id);
}
