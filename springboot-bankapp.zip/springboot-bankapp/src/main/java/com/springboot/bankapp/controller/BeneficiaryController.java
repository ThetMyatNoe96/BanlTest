package com.springboot.bankapp.controller;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.bankapp.dto.BeneficiaryDto;
import com.springboot.bankapp.model.Beneficiary;
import com.springboot.bankapp.service.BeneficiaryService;

@RestController
@RequestMapping("/beneficiary")
public class BeneficiaryController {

	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private BeneficiaryService benefiService;
	
	@PostMapping("/register")
	public ResponseEntity<BeneficiaryDto> saveBeneficiary(@RequestBody Beneficiary beneficiary){
						
		
		Beneficiary beneficiaryInfo=benefiService.saveBeneficiary(beneficiary);
		BeneficiaryDto benefiResponse=modelMapper.map(beneficiaryInfo, BeneficiaryDto.class);
		return new ResponseEntity<BeneficiaryDto>(benefiResponse, HttpStatus.CREATED);			
	}	

}
