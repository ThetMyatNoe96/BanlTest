package com.springboot.bankapp.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.springboot.bankapp.model.Account;

public interface AccountRepository extends JpaRepository<Account, Long>{

	 @Query(value = "SELECT balance FROM account WHERE user_id = :user_id AND account_id = :account_id", nativeQuery = true)
	    double getAccountBalance(@Param("user_id") long user_id, @Param("account_id") long account_id);

	    @Modifying
	    @Query(value ="UPDATE accounts SET balance = :new_balance WHERE account_id = :account_id" , nativeQuery = true)
	    @Transactional
	    void changeAccountBalanceById(@Param("new_balance") double new_balance, @Param("account_id") long account_id);
}
