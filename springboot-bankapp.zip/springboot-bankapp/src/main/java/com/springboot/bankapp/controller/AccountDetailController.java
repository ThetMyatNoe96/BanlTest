package com.springboot.bankapp.controller;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.springboot.bankapp.dto.AccountDto;

import com.springboot.bankapp.model.Account;

import com.springboot.bankapp.service.AccountService;

@RestController
@RequestMapping("/account")
public class AccountDetailController {
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private AccountService accountService;		
	
	
	@GetMapping("{id}")
	public ResponseEntity<AccountDto> getAccDetailsById(@PathVariable("id") long accountId){		
		
		Account acc=accountService.getAccountById(accountId);		
		AccountDto accResponse=modelMapper.map(acc, AccountDto.class);
		return new ResponseEntity<AccountDto>(accResponse,HttpStatus.OK);
		
	}	
	
	
}
