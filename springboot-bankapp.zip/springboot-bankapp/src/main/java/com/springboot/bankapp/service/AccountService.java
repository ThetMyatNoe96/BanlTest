package com.springboot.bankapp.service;

import com.springboot.bankapp.model.Account;


public interface AccountService {

	Account saveAccount(Account account);
	
	Account getAccountById(long id);
	
	
}
